num = [6 26 6 20];
den = [1 3 4 2 2];
w = 0.1:0.001:100;
nyquist(num,den,w);
title('ϵͳnyquistͼ');


