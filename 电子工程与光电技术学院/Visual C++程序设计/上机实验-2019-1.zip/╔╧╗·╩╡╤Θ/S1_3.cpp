#include <iostream>
using namespace std;

int main()
{
	const double pi=3.14159;
	double r,s;
	cin >> r;
	s=pi*r*r;
	cout << s;
	return 0;
}